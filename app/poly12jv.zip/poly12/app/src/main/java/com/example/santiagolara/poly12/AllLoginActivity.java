package com.example.santiagolara.poly12;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AllLoginActivity extends AppCompatActivity {

    //All Login Functionality will go here
    //Manual Sign-In
    //Google Sign-In
    //Add Gradle scripts and connect this Project to Firebase
    //Enable Sign-In for Email/Password and Google Sign-In
    //After code is done, link sign-in to Language Intro Activity class and layout,
    // make a GoToProfile connection where user can see their information and  sign out.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_login);


    }
}
